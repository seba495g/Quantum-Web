import "./compiler.js"
import "./gitimport.js"
s__=`
    q:out >> Hello world!
`