/*
 * All code rights are owned by "seba495g" on github.
 * importing code by &import gitimport.qua
 * official file, gitimport.qua
 * source owner, seba495g
 * --
 * exporting the code needed to compile
*/
export function compile(){ //exporting the code to compile it, into low-level code
    if(s__.includes("q:out >> ")){console.log(i__.split("q:out >> ")[1].trim());}
}
