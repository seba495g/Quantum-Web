let s__;
import { compile } from "gitimport.js"
/**
 * all rights of the is owned by "seba495g" in github. 
 * search "Quantum" on github
 * --
 * Compiling Quantum code into low-level code (maybe JavaScript)
 */
if(s__.includes("q:out >> ")){console.log(s__.split("q:out >> ")[1].trim());}
if(s__.startswith("&import gitimport.qua")){
    if(s__.includes("q:in >> ")){prompt(s__.split("q:in >> ")[1].trim());}
}
